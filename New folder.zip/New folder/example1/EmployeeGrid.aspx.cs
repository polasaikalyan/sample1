﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace example1
{
    public partial class EmployeeGrid : System.Web.UI.Page
    {
        static string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
        SqlConnection con = new SqlConnection(str);
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                refreshdata();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEmployee.aspx");
        }
        protected void displayemp()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from kaly.Employee", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            int count = ds.Tables[0].Rows.Count;
            con.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
                GridView1.DataSource = ds;
                GridView1.DataBind();
                int columncount = GridView1.Rows[0].Cells.Count;
            }
        }
        public void refreshdata()
        {
            SqlCommand sc = new SqlCommand("kaly.display", con);
            sc.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(sc);
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditButton")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                Session["type"] = "update";
                Response.Redirect("~/AddNewEmployee.aspx?EmpId=" + row.Cells[1].Text);
            }

            if (e.CommandName == "DeleteButton")
            {
                string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
                SqlConnection con = new SqlConnection(str);
                try
                {
                    SqlCommand sc = new SqlCommand("kaly.Employee_delete", con);
                    sc.CommandType = CommandType.StoredProcedure;
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    sc.Parameters.AddWithValue("@EmployeeId", Convert.ToInt32(row.Cells[1].Text));
                    con.Open();
                    sc.ExecuteNonQuery();
                    Response.Write("One row deleted");
                    con.Close();
                    Response.Redirect("EmployeeGrid.aspx");
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}