﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace example1
{
    public partial class AddEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request["EmpId"] != null)
            {
               // UpdateData(Convert.ToInt16(Request["EmpId"]));
            }
        }

        protected void AddBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string empname = this.empname.Text;
                string Emailid = this.emailid.Text;
                string Address = this.address.Text;
                string PhoneNumber = this.phoneno.Text;
                string Gender = this.gender.Text;
                DateTime DOB = Convert.ToDateTime(this.dob.Text);
                string Designation = this.designation.Text;


                string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
                SqlConnection con = new SqlConnection(str);
                SqlCommand sc;
                if (this.Add.Text == "Add")
                {
                    sc = new SqlCommand("kaly.Emp_Save", con);
                    sc.CommandType = CommandType.StoredProcedure;

                    sc.Parameters.AddWithValue("@EmployeeName", empname);
                    sc.Parameters.AddWithValue("@EmailId", Emailid);
                    sc.Parameters.AddWithValue("@Address", Address);
                    sc.Parameters.AddWithValue("@Designation", Designation);
                    sc.Parameters.AddWithValue("@PhoneNumber", Convert.ToInt64(PhoneNumber));
                    sc.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB));
                    sc.Parameters.AddWithValue("@Gender", Gender);

                    con.Open();
                    sc.ExecuteNonQuery();
                    Response.Redirect("EmployeeGrid.aspx");
                }
                else
                {
                    empname = this.empname.Text;
                    int EmpId = Convert.ToInt16(Request.Cookies["EmpID"].Value.ToString());
                    Response.Cookies["EmpID"].Expires = DateTime.Now.AddDays(-1);
                    using (var cmd = new SqlCommand($"update kaly.Employee set EmployeeName = @EmployeeName, EmailId = @EmailId, Designation=@Designation,PhoneNumber = @PhoneNumber, Address = @Address,DOB = @DOB, Gender=@Gender where EmployeeId = @EmployeeId", con))
                    {
                        cmd.Parameters.Add("@EmployeeName", SqlDbType.VarChar).Value = empname;
                        cmd.Parameters.Add("@EmailId", SqlDbType.VarChar).Value = Emailid;
                        cmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = Designation;
                        cmd.Parameters.Add("@PhoneNumber", SqlDbType.BigInt).Value = PhoneNumber;
                        cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = Address;
                        cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = DOB;
                        cmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = Gender;
                        cmd.Parameters.Add("@EmployeeId", SqlDbType.Int).Value = EmpId;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        Response.Redirect("EmployeeGrid.aspx");
                    }
                    //sc.Parameters.Add()
                    //con.Open();
                }
            }
            catch (Exception er)
            {
                Response.Write(er.Message.ToString());
            }
        }
        protected void LnkDelete_Click(object sender, EventArgs e)
        {
            string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
            SqlConnection con = new SqlConnection(str);
            try
            {
                SqlCommand sc = new SqlCommand("kaly.Employee_delete", con);
                sc.CommandType = CommandType.StoredProcedure;

                int a = Convert.ToInt32(empname.Text);
                sc.Parameters.AddWithValue("@EmployeeName", a);
                con.Open();
                sc.ExecuteNonQuery();
                Response.Write("One row deleted");
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }
        protected void LnkEdit_Click(object sender, EventArgs e)
        {
          
                string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
                SqlConnection con = new SqlConnection(str);

            string EmpId = null;
            //SqlCommand sc = new SqlCommand("select * from kaly.Employee where EmployeeId=" + EmpId , con);
            SqlCommand sc = new SqlCommand("select * from kaly.Employee where EmployeeId=" + EmpId, con);
                con.Open();
                SqlDataReader reader = sc.ExecuteReader();
                while (reader.Read())
                {
                    this.empname.Text = Convert.ToString(reader.GetValue(1));
                    this.emailid.Text = Convert.ToString(reader.GetValue(2));
                    this.designation.Text = Convert.ToString(reader.GetValue(3));
                    this.phoneno.Text = Convert.ToString(reader.GetValue(4));
                    this.address.Text = Convert.ToString(reader.GetValue(5));
                    this.dob.Text = Convert.ToString(reader.GetValue(6));
                    this.gender.Text = Convert.ToString(reader.GetValue(7));
                    this.Add.Text = "Update";
                }
                reader.Close();
                sc.Dispose();
                con.Close();

            
        }
    }
}